# $Id: test_bytecode.py 1740 2007-01-21 22:01:34Z peter $
from tests import TestCase, add
from yasm import Bytecode, Expression

