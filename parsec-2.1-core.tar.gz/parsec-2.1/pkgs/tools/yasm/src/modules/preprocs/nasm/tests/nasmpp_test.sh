#! /bin/sh
# $Id: nasmpp_test.sh 1137 2004-09-04 01:24:57Z peter $
${srcdir}/out_test.sh nasmpp_test modules/preprocs/nasm/tests "nasm preproc" "-f bin" ""
exit $?
