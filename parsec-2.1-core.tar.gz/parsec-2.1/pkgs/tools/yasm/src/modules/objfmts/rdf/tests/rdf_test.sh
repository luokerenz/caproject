#! /bin/sh
# $Id: rdf_test.sh 1653 2006-10-17 06:58:41Z peter $
${srcdir}/out_test.sh rdf_test modules/objfmts/rdf/tests "rdf objfmt" "-f rdf" ".rdf"
exit $?
