#! /bin/sh
# $Id: win64_test.sh 1252 2005-09-28 05:50:51Z peter $
${srcdir}/out_test.sh win64_test modules/objfmts/win64/tests "win64 objfmt" "-f win64" ".obj"
exit $?
