#! /bin/sh
# $Id: xdf_test.sh 1151 2004-09-29 03:36:52Z peter $
${srcdir}/out_test.sh xdf_test modules/objfmts/xdf/tests "xdf objfmt" "-f xdf" ".xdf"
exit $?
