#! /bin/sh
# $Id: win32_test.sh 1137 2004-09-04 01:24:57Z peter $
${srcdir}/out_test.sh win32_test modules/objfmts/win32/tests "win32 objfmt" "-f win32" ".obj"
exit $?
