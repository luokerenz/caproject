#! /bin/sh
# $Id: lc3b_test.sh 1137 2004-09-04 01:24:57Z peter $
${srcdir}/out_test.sh lc3b_test modules/arch/lc3b/tests "lc3b arch" "-a lc3b -f bin" ""
exit $?
