#! /bin/sh
# $Id: x86_test.sh 1137 2004-09-04 01:24:57Z peter $
${srcdir}/out_test.sh x86_test modules/arch/x86/tests "x86 arch" "-f bin" ""
exit $?
