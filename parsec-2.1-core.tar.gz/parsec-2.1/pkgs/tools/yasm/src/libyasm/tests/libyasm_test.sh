#! /bin/sh
# $Id: libyasm_test.sh 1137 2004-09-04 01:24:57Z peter $
${srcdir}/out_test.sh libyasm_test libyasm/tests "libyasm" "-f bin" ""
exit $?
