extern int foo3(void);
int foo2(void) { return foo3(); }
