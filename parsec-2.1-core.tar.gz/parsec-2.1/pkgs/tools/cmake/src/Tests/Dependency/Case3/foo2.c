extern int foo1b(void);
int foo2(void) { return foo1b(); }
