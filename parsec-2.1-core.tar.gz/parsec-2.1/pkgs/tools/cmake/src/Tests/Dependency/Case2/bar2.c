extern int bar3(void);
int bar2(void) { return bar3(); }
