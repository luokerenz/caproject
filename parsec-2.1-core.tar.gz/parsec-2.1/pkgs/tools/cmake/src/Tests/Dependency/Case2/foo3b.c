int foo3b(void) { return 0; }
