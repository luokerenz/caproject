void SevenFunction();

void EightFunction()
{
  SevenFunction();
}
