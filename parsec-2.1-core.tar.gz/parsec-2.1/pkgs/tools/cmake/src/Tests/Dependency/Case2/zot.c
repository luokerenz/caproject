extern int bar1(void);
int main(void)
{
  return bar1();
}
