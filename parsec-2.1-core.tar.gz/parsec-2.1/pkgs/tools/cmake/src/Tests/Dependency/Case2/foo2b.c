extern int foo3b(void);
int foo2b(void) { return foo3b(); }
