extern int foo1(void);
int main(void)
{
  return foo1();
}
