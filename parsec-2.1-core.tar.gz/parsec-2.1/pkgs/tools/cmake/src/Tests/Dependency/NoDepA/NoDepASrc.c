void NoDepAFunction()
{
}
