void FiveFunction();
void TwoFunction();

void SixAFunction()
{
  FiveFunction();
  TwoFunction();
}
