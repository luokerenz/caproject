#include "generated.h"
int main()
{
  return 0;
}
