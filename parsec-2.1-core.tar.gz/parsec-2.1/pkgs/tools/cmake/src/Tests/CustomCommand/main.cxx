extern int generated();

int main()
{
  return generated();
}
