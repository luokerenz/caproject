#if 1

int gen_redirect() { return 3; }

/* endif should be concatenated to generated file */
