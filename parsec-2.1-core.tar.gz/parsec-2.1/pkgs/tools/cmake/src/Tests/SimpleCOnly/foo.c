int foo() { return 12;}
