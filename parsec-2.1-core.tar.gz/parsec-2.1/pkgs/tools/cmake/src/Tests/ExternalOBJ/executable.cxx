extern int external_object_function();
int main()
{
  return external_object_function();
}
