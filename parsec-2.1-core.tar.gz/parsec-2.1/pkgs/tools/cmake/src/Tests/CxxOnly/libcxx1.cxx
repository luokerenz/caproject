#include "libcxx1.h"

float LibCxx1Class::Method()
{
  return 2.0;
}
