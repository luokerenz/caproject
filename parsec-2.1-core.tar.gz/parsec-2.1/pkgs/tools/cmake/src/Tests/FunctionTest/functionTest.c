#include <stdio.h>

int main(int argc, char* argv[])
{
  printf("Running command: %s with %d arguments\n", argv[0], argc);
  return 0;
}
