#include <stdio.h>

void vcl_stuff()
{
  printf("Placeholder for a file with strange name\n");
}
